# Tarea Grupal "DESARROLLAR UNA APLICACIÓN MÓVIL ANDROID CON EL USO DE LOS CONTROLES COMUNES DE LA INTERFAZ DE USUARIO (UI) DE ANDROID"
## Integrantes: 
Erick Moran Garcez  
Wimper Josue Triana  
Kiara Intriago  
Jose Lopez  
Cristhian Ortega

<img src="captura1.png" width="200" height="400">
----------<br>
----------
<img src="captura2.png" width="200" height="400">
----------<br>
----------
<img src="captura3.png" width="200" height="400">
----------<br>
----------
<img src="cap3.png" width="200" height="400">
----------<br>
----------
<img src="cap4.png" width="200" height="400">
----------<br>
<img src="cap5.png" width="200" height="400">
----------<br>
----------
----------
